Meta is a domain specific language for Python that enables powerful forms of code sharing.
